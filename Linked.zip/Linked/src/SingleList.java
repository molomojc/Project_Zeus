
/**
 * @version Practical 01
 * @author Jacob 
 */
public class SingleList {
  //this will store the types of nodes
	private Node head;
	
	public SingleList()
	{
		this.head = null; //point the current Head to null meanign the starts
	}

	/**
	 * 
	 * @param item
	 */
	public void append(ProductItem item)
	{
		Node _Node = new Node(item); //your storing the item into Node
		if(head == null)
		{
			head = _Node;  //now here your checking if the node is empty , if the head is empty then the new node becomes the new node
		}
		else
		{
			Node current = head;
			while(current.next != null)
			{
				current = current.next;
			}
			current.next = _Node;
		}
	}
   
	// Add an element after a given node
    public void addAfter(Node targetNode, ProductItem item) {
        if (targetNode == null) {
            System.out.println("Target node cannot be null.");
            return;
        }
        Node newNode = new Node(item);
        newNode.next = targetNode.next;
        targetNode.next = newNode;
    }
	public void addBefore(Node targetNode, ProductItem item) {
	    if (head == null || targetNode == null) 
	    	{
	    	 System.out.println("Target node cannot be null.");
	    	return;
	    	}
	    
	    if (targetNode == head) { // Insert at the beginning
	        Node newNode = new Node(item);
	        newNode.next = head;
	        head = newNode;
	        return;
	    }
	    Node current = head;
	    while (current.next != null && current.next != targetNode) {
	        current = current.next;
	    }
	    if (current.next == targetNode) {
	        Node newNode = new Node(item);
	        newNode.next = targetNode;
	        current.next = newNode;
	    }
	}
	
	// Remove a specified node from the list
    public ProductItem remove(Node targetNode) {
        if (head == null || targetNode == null) {
            System.out.println("List is empty or target node is null.");
            return null;
        }
        if (targetNode == head) {
            head = head.next;
            return targetNode._Data;
        }
        Node current = head;
        while (current.next != null && current.next != targetNode) {
            current = current.next;
        }
        if (current.next == targetNode) {
            current.next = targetNode.next;
            return targetNode._Data;
        } else {
            System.out.println("Target node not found in the list.");
            return null;
        }
    }

   // Search for a node containing a specific product item
    public Node search(String productName) {
        Node current = head;
        while (current != null) {
            if (current._Data.toString().contains(productName)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node current = head;
        while (current != null) {
            sb.append(current._Data.toString()).append("\n");
            current = current.next;
        }
        return sb.toString();
    }
}
