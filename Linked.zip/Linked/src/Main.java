
/*
 * 
 * @Auther JM Molomo
 * @Version Practical 01
 */
 // Main class to handle file operations and user interaction

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Main {
    private static final String FILE_NAME = "spending_tracker.dat";

    // Write a ProductItem to the binary file
    public static void writeProductItemToFile(ProductItem item) {
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME, true);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(item);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Read all ProductItems from the binary file into an SList
    public static SingleList readProductItemsFromFile() {
    	SingleList list = new SingleList();
        try (FileInputStream fis = new FileInputStream(FILE_NAME);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                try {
                    ProductItem item = (ProductItem) ois.readObject(); //casting it into the object
                    list.append(item); //append it to the list so we can read it
                } catch (EOFException e) {
                    break; // End of file reached
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Main method for user interaction
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SingleList list = readProductItemsFromFile();

        while (true) {
            System.out.println("\n1. Add Product\n2. View Products\n3. Add After\n4. Add Before\n5. Remove\n6. Search\n7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline



switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter product price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter product quantity: ");
                    int quantity = scanner.nextInt();
                    ProductItem newItem = new ProductItem(name, price, quantity);
                    list.append(newItem);
                    writeProductItemToFile(newItem);
                    break;
                case 2:
                    System.out.println(list.toString());
                    break;
                case 3:
                    System.out.print("Enter product name to add after: ");
                    String afterName = scanner.nextLine();
                    Node afterNode = list.search(afterName);
                    if (afterNode != null) {
                        System.out.print("Enter new product name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new product price: ");
                        double newPrice = scanner.nextDouble();
                        System.out.print("Enter new product quantity: ");
                        int newQuantity = scanner.nextInt();
                        ProductItem afterItem = new ProductItem(newName, newPrice, newQuantity);
                        list.addAfter(afterNode, afterItem);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter product name to add before: ");
                    String beforeName = scanner.nextLine();
                    Node beforeNode = list.search(beforeName);
                    if (beforeNode != null) {
                        System.out.print("Enter new product name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new product price: ");
                        double newPrice = scanner.nextDouble();
                        System.out.print("Enter new product quantity: ");
                        int newQuantity = scanner.nextInt();
                        ProductItem beforeItem = new ProductItem(newName, newPrice, newQuantity);
                        list.addBefore(beforeNode, beforeItem);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 5:
                    System.out.print("Enter product name to remove: ");
                    String removeName = scanner.nextLine();
                    Node removeNode = list.search(removeName);
                    if (removeNode != null) {
                        ProductItem removedItem = list.remove(removeNode);
                        System.out.println("Removed: " + removedItem);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 6:
                    System.out.print("Enter product name to search: ");
                    String searchName = scanner.nextLine();
                    Node foundNode = list.search(searchName);
                    if (foundNode != null) {
                        System.out.println("Found: " + foundNode._Data);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
