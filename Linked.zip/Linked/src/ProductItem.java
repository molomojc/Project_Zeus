import java.io.Serializable;


/*
 * This implements the serializable so that it is able to be saved to a file
 * 
 */
public class ProductItem implements Serializable {
     private String name; //the name of the item that is bought
     private double price; //the name of the price that is bought
     private int quantity; //the quantity of the item that is bought

     public ProductItem(String name, double price, int quant)
     {
    	 this.name = name;
    	 this.price = price;
    	 this.quantity = quant;
     }
     @Override
     public String toString() {
         return "Product: " + name + ", Price: R" + price + ", Quantity: " + quantity;
     }
}
