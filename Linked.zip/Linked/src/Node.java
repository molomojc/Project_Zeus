

/*
 * This is the piece of the node which will hold the 
 * Product item in the LinkedList
 */
public class Node {
  //So have to create a type of the ProductItem 
	ProductItem _Data;
	//Now store the next node
	Node next; // you are technically creating the next same object

	
	//create a constructor which initializes this object
	public Node(ProductItem data)
	{
		this._Data = data; //storing the current data into the procutItem
		this.next = null;
	}
}
