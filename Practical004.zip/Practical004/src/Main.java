import java.util.Scanner;
import java.util.StringTokenizer;
/*
 * Total Marks Main Class: 25
 * Compilation & Correct Execution Marks: 10
 */
public class Main {
	static LinkedQueue<Transaction> buyQueue = new LinkedQueue<Transaction>();
	static LinkedQueue<Transaction> sellQueue = new LinkedQueue<Transaction>();
	static int totalGain = 0;
	
	/**
	 * Process queue of transactions - determine if each transaction is a buy or sell
	 * transaction & add it to the appropriate queue
	 * @param transactions - a queue of buy and sell transactions
	 * 15 marks
	 */
	public static void processTransactions(LinkedQueue<String> transactions) {
	 

	    // Process all transactions in the queue
	    while (!transactions.isEmpty()) {
	        String line = transactions.dequeue(); // Get the next transaction
	        StringTokenizer sn = new StringTokenizer(line, " ");
	        String type = sn.nextToken(); // Transaction type (BUY or SELL)
	        int quantity = Integer.parseInt(sn.nextToken()); // Quantity of shares
	        int price = Integer.parseInt(sn.nextToken()); // Price per share

	        // Add the transaction to the appropriate queue
	        if (type.equalsIgnoreCase("BUY") ||  type.equals("buy")) {
	            buyQueue.enqueue(new Transaction(quantity, price));
	        } else if (type.equalsIgnoreCase("SELL") || type.equals("sell")) {
	            sellQueue.enqueue(new Transaction(quantity, price));
	        } else {
	            System.out.println("Invalid transaction type: " + type);
	        }
	    }
	}
	
	/**
	 * Calculate capital gain(loss)
	 * @return totalGain
	 * 10 marks
	 */
	public static Integer calculateCapitalGainLoss() {

		    // Process all sell transactions
		    while (!sellQueue.isEmpty()) {
		        Transaction sellTransaction = sellQueue.dequeue();
		        int sellQuantity = sellTransaction.getQuantity();
		        int sellPrice = sellTransaction.getUnitPrice();

		        // Process the sell transaction using the FIFO protocol
		        while (sellQuantity > 0 && !buyQueue.isEmpty()) {
		            Transaction buyTransaction = buyQueue.first();
		            int buyQuantity = buyTransaction.getQuantity();
		            int buyPrice = buyTransaction.getUnitPrice();

		            int sharesToSell = Math.min(sellQuantity, buyQuantity);
		            totalGain += sharesToSell * (sellPrice - buyPrice);

		            sellQuantity -= sharesToSell;
		            if (sharesToSell == buyQuantity) {
		                buyQueue.dequeue(); // Remove the buy transaction if all shares are sold
		            } else {
		                buyTransaction.setQuantity(buyQuantity - sharesToSell); // Update remaining shares
		            }
		        }
		    }

		    return totalGain;
		
	}
	
	public static void main(String[] args) {
		String response = "";
		Scanner s = new Scanner(System.in);
		LinkedQueue<String> instructionQueue = new LinkedQueue<String>();
		Integer capGainLoss;
		
		while (!response.toLowerCase().equals("quit")){
			System.out.println("Select option: ");
			System.out.println("1) Enter new transaction");
			System.out.println("2) Calculate capital gain or loss");
			System.out.println("or \"quit\" to quit.");
			response = s.nextLine();
			
			switch(response.toLowerCase()){
				case "1": {
					System.out.println("Enter transaction:");
					response = s.nextLine();
					if (!response.equals(""))
						instructionQueue.enqueue(response);
				}
					break;
				case "2": {
					processTransactions(instructionQueue);
					capGainLoss = calculateCapitalGainLoss();
					if (capGainLoss == null)
						System.out.println("Unmatched sell transaction(s).");
					else
						System.out.println("Capital Gain/Loss: "+capGainLoss);
				}
					break;
				case "quit": break;
				default: System.out.println("Incorrect option selected. Please try again.");
			}			
		}
	}
}