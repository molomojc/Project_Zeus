

public class Main {

	public static void main(String[] args) {
		Testing test = new Testing();
		
		test.func();

	}

}
