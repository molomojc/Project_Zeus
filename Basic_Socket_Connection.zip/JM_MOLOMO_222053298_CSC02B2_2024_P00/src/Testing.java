

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Testing {
	
	public void func() {
	           
	            int _IP = 65535;
	            for (int i = 1; i < _IP; i += 3) {
	                try (Socket connection = new Socket("localHost", i)) { //ARM
	                    System.out.println("Program connected to localhost port: " + connection.getPort());
	                    System.out.println("Local port of the connection: " + connection.getLocalPort());
	                    System.out.println("Remote port of the connection: " + connection.getPort());
	                } catch (IOException e) {
	                    System.out.println("Could not connect to localhost port: " + i);
	                }
	            }
	            
	           try {
	        	   System.out.println("The computer's IP address: " + InetAddress.getLocalHost().getHostAddress());
	           }
	         catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
