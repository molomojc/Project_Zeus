//Overall Main class: 30 marks ***********************************************
//Correctness (10 marks) ********************************
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Main {
	/**
     * Extracts 8x8 grayscale patches from an image.
     * @param image Input BufferedImage.
     * @return PositionList of 8x8 patches.
     */
	public static PositionList<Patch> extractPatches(BufferedImage image) {
	    PositionList<Patch> patches = new PositionList<>();

	    if (image == null || image.getWidth() < 8 || image.getHeight() < 8) {
	        throw new IllegalArgumentException("Image too small to extract 8x8 patches.");
	    }

	    for (int y = 0; y <= image.getHeight() - 8; y += 8) {
	        for (int x = 0; x <= image.getWidth() - 8; x += 8) {
	            double[][] patchData = new double[8][8];

	            for (int dy = 0; dy < 8; dy++) {
	                for (int dx = 0; dx < 8; dx++) {
	                    int rgb = image.getRGB(x + dx, y + dy);

	                    int r = (rgb >> 16) & 0xff;
	                    int g = (rgb >> 8) & 0xff;
	                    int b = rgb & 0xff;

	                    // Use perceptual brightness for better grayscale conversion (optional)
	                    int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);

	                    patchData[dy][dx] = gray;
	                }
	            }

	            patches.addLast(new Patch(patchData, x, y));
	        }
	    }

	    return patches;
	}


    /**
     * Reconstructs an image from a list of patches.
     * @param patches PositionList of selected patches.
     * @param width Width of the final image.
     * @param height Height of the final image.
     * @return Reconstructed BufferedImage.
     * 10 marks ***********************************************
     */
    public static BufferedImage renderScene(PositionList<Patch> patches, int width, int height) {
        BufferedImage result = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        
        // Initialize the result image with black pixels
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                result.setRGB(x, y, 0); // Black
            }
        }
        
        // Place each patch in its original position
        for (Position<Patch> pos = patches.first(); pos != null; pos = patches.next(pos)) {
            Patch patch = pos.element();
          if (patch == null) continue; // Skip null patches
            
            int startX = patch.getX();
            int startY = patch.getY();
            double[][] patchData = patch.getData();

            for (int dy = 0; dy < 8; dy++) {
                for (int dx = 0; dx < 8; dx++) {
                    if (startX + dx < width && startY + dy < height) {
                        int grayValue = (int) patchData[dy][dx];
                        int rgb = (grayValue << 16) | (grayValue << 8) | grayValue;
                        result.setRGB(startX + dx, startY + dy, rgb);
                    }
                }
            }
        }
        
        return result;
    }



    public static void main(String[] args) throws IOException {
    	File[] imageFiles = new File("scenes/").listFiles((dir, name) -> name.endsWith(".jpg"));
        if (imageFiles == null || imageFiles.length == 0) {
            System.err.println("No JPG images found in scenes/ directory");
            return;
        }

        // 2. Determine output size from first image
        BufferedImage firstImage = ImageIO.read(imageFiles[0]);
        int outputWidth = firstImage.getWidth();
        int outputHeight = firstImage.getHeight();
        
        // Alternatively, set fixed size if preferred:
        // outputWidth = 400;
        // outputHeight = 400;

        PositionList<Patch> allPatches = new PositionList<>();

        // 3. Extract patches with position normalization
        for (File file : imageFiles) {
            BufferedImage img = ImageIO.read(file);
            if (img == null) continue;

            // Resize if needed to match output dimensions
            if (img.getWidth() != outputWidth || img.getHeight() != outputHeight) {
                img = resizeImage(img, outputWidth, outputHeight);
            }

            PositionList<Patch> patches = extractPatches(img);
            for (Position<Patch> pos = patches.first(); pos != null; pos = patches.next(pos)) {
                allPatches.addLast(pos.element());
            }
        }
        // Pick a reference patch (e.g., the first one in the list)
        Patch referencePatch = allPatches.first().element(); // You could also load from a specific image

        // Heap insertion – rank patches by similarity (Hamming distance)
        Heap<Long, Patch> patchHeap = new Heap<>();
        for (Position<Patch> pos = allPatches.first(); pos != null; pos = allPatches.next(pos)) {
            Patch patch = pos.element();
            if (patch != null) {
                int similarity = referencePatch.similarity(patch); // lower = more similar
                patchHeap.insert((long) similarity, patch); // key = similarity score
            }
        }

        // Select top patches (e.g., top 100 most similar)
        PositionList<Patch> bestPatches = new PositionList<>();
        int patchCount = 100;
        for (int i = 0; i < patchCount && !patchHeap.isEmpty(); i++) {
            Entry<Long, Patch> entry = patchHeap.removeMin();
            bestPatches.addLast(entry.getValue());
        }

        // Reconstruct and save the image
        BufferedImage result = renderScene(bestPatches, 200, 200);
        
        ImageIO.write(result, "png", new File("completed_scene1.png"));
        
        System.out.println("i am done");
    }
    
 // Helper method to resize images
    private static BufferedImage resizeImage(BufferedImage original, int width, int height) {
        BufferedImage resized = new BufferedImage(width, height, original.getType());
        Graphics2D g = resized.createGraphics();
        g.drawImage(original, 0, 0, width, height, null);
        g.dispose();
        return resized;
    }

}