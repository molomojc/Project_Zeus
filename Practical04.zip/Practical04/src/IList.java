
/**
 * The interface
 * @param <T>
 */
public interface IList<T> {
     public    int size();
     public   boolean isEmpty();
     public   void add(T data);
     public   T remove();
     public   T peek();
}
