
/**
 * The class to hold the actual information about the data or element 
 * @author Jacob Molomo
 * @version Practical 04
 */
public class Share {
     private int Quantity;
     private double price;
     
     /**
      * 
      * @param quantity
      * @param price
      */
     public Share(int quantity, double price)
     {
    	 this.setQuantity(quantity);
    	 this.setPrice(price);
     }

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return Quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	

	public String toString()
	{
		return "R" + Quantity + ":" +price;
	}

     
     
}
