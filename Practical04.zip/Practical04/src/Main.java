public class Main {
    public static void main(String[] args) {
        LinkedQueue<Share> queue = new LinkedQueue<>();
        processTransactions(queue);
        double capitalGainLoss = calculateCapitalGainLoss(queue);
        System.out.println("Capital Gain/Loss: R" + capitalGainLoss);
    }

    public static void processTransactions(LinkedQueue<Share> queue) {
        // Example transactions
        queue.add(new Share(100, 20));
        System.out.println("Transaction: BUY 100 20");
        queue.add(new Share(20, 24));
        System.out.println("Transaction: BUY 20 24");
        queue.add(new Share(200, 36));
        System.out.println("Transaction: BUY 200 36");

        // Sell 150 shares at R30 each
        int sharesToSell = 150;
        double sellingPrice = 30;
        System.out.println("Transaction: SELL " + sharesToSell + " " + sellingPrice);
    }

    public static double calculateCapitalGainLoss(LinkedQueue<Share> queue) {
        int sharesToSell = 150;
        double sellingPrice = 30;
        double capitalGainLoss = 0;

        while (sharesToSell > 0 && !queue.isEmpty()) {
            Share share = queue.peek();
            int sharesAvailable = share.getQuantity();
            double purchasePrice = share.getPrice();

            int sharesSold = Math.min(sharesAvailable, sharesToSell);
            capitalGainLoss += sharesSold * (sellingPrice - purchasePrice);

            sharesToSell -= sharesSold;
            if (sharesSold == sharesAvailable) {
                queue.remove();
            } else {
                share.setQuantity(sharesAvailable - sharesSold);
            }
        }

        return capitalGainLoss;
    }
}