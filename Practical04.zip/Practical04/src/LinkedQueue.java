
public class LinkedQueue<T> implements IList<T> {
    private Node<T> front;
    private Node<T> rear;
    private int size;
    
    public LinkedQueue()
    {
    	front = null;
    	rear = null;
    	size = 0;
    }
	

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if(size == 0)
			return true;
		else 
			return false;
	}

	@Override
	public void add(T data) {
		// TODO Auto-generated method stub
		Node<T> nNode = new Node<>(data);
		if(isEmpty() == true)
		{
			front = nNode;
		}
		else
		{
			rear.setNext(nNode);
		}
		rear = nNode;
		size++;
	}

	@Override
	public T remove() {
		// TODO Auto-generated method stub
		if(isEmpty() == true)
		{
			System.out.println("Queu is empty");
			return null;
		}
		T data = front.getData();
		front = front.getNext();
		size--;
		if(isEmpty())
		{
			rear = null;
		}
		return data;
	}

	@Override
	public T peek() {
		if(isEmpty() == true)
		{
			System.out.println("Queu is empty");
			return null;
		}
		return front.getData();
	}
	
	/**
	 * Provide a deep copy of the Linked List
	 */
	@Override
	public LinkedQueue<T> clone() {
		
		 LinkedQueue<T> clonedList = new  LinkedQueue<>();
		Node<T> current = front;
		while(current != null)
		{
			clonedList.add(current.getData());
			current = current.getNext();
		}
		  return clonedList;

		
	}


}
