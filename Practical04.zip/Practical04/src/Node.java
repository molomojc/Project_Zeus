

/**
 * @author Jacob Molomo
 * @version Practical 04
 * @param <T>
 */
public class Node<T> {
     private T data;
     private Node<T> next;
 
      /**
       * Default Constructor
       * @param data
       */
     public Node(T data)
     {
    	 this.setData(data) ;
    	 this.setNext(null);
     }

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	/**
	 * @return the next
	 */
	public Node<T> getNext() {
		return next;
	}

	/**
	 * @param next the next to set
	 */
	public void setNext(Node<T> next) {
		this.next = next;
	}
	
	public String toString() {
		if (data == null) {
			return "<>";
		}
		return "<" + data.toString() + ">";
	}

}
