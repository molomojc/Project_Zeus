import java.util.Iterator;
import java.util.ArrayList;

public class TreeNode<T> implements Position<T> {
    T element = null;
    private ArrayList<Position<T>> children = null;
    private TreeNode<T> parent = null;
    
    // 3 marks
    public TreeNode(TreeNode<T> parent, T element) {
        this.parent = parent;
        this.element = element;
        this.children = new ArrayList<Position<T>>();
    }
    
    // 2 marks
    public Iterator<Position<T>> getChildren() {
        return children.iterator();
    }
    
    // 5 marks
    public TreeNode<T> addChild(T newChild) {
        TreeNode<T> newNode = new TreeNode<T>(this, newChild);
        children.add(newNode);
        return newNode;
    }
    
    public void setElement(T element) {
        this.element = element;
    }
    
    @Override
    public T element() {
        return element;
    }
    
    public TreeNode<T> getParent(){
        return parent;
    }
    
    public String toString() {
        return element.toString();        
    }
}