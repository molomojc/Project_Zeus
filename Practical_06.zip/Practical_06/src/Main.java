//************ Total marks for Main: 10 marks ************************************
import java.util.Iterator;
import java.util.Random;

class Mark{
	String name;
	Integer value;
	
	public Mark(String name, Integer value) {
		this.name = name;
		this.value = value;
	}

	@Override
	public String toString() {
		if (name!=null)
			return name + " " + value;
		else
			return String.valueOf(value);
	}	
}

public class Main {

	public static void main(String[] args) throws Exception {
		Random r = new Random(System.currentTimeMillis());
		//(r.nextInt(100)
		Tree<Mark> tree = new Tree<Mark>(new Mark("CSC3A", 100));
		Position<Mark> root = tree.root();
		
		Position<Mark> st = tree.addElementAsChild(root, new Mark("ST", 50));
		Position<Mark> st1 = tree.addElementAsChild(st, new Mark(null, 16 ));
		Position<Mark> st2 = tree.addElementAsChild(st, new Mark(null, 78));
		
		Position<Mark> miniP = tree.addElementAsChild(root, new Mark("MP", 25));
		Position<Mark> mp = tree.addElementAsChild(miniP, new Mark(null, 68));
		
		Position<Mark> ct_pa = tree.addElementAsChild(root, new Mark("CT+PA", 25));
		
		Position<Mark> ct = tree.addElementAsChild(ct_pa, new Mark("CT", 50));		
		Position<Mark> ctm = tree.addElementAsChild(ct, new Mark(null, 55));
		Position<Mark> ctmm = tree.addElementAsChild(ct, new Mark(null, 47));
		Position<Mark> ctmmm = tree.addElementAsChild(ct, new Mark(null, 68));
		
		/*
		for(int i=0;i<3;i++){
			tree.addElementAsChild(ct, new Mark(null, (r.nextInt(100))));
		}
		*/
		
		Position<Mark> pa = tree.addElementAsChild(ct_pa, new Mark("PA", 50));		
		Position<Mark> pt1 = tree.addElementAsChild(pa, new Mark(null, 42));
		Position<Mark> pt2 = tree.addElementAsChild(pa, new Mark(null, 77));
		Position<Mark> pt3 = tree.addElementAsChild(pa, new Mark(null, 12));
		Position<Mark> pt4 = tree.addElementAsChild(pa, new Mark(null, 42));
		Position<Mark> pt5 = tree.addElementAsChild(pa, new Mark(null, 55));
		Position<Mark> pt6 = tree.addElementAsChild(pa, new Mark(null, 33));
		Position<Mark> pt7 = tree.addElementAsChild(pa, new Mark(null, 91));
		Position<Mark> pt8 = tree.addElementAsChild(pa, new Mark(null, 3));
	//	Position<Mark> pt1 = tree.addElementAsChild(ct, new Mark(null, 68));
		
		System.out.println(tree.preOrderElementTraversal(tree, root));
		System.out.println("\nSemester Mark:" + calcSM(tree, tree.root()));
	}
	
	/**
	 * Calculate the semester mark using the weights and marks contained in the tree
	 * @param tree
	 * @return the semester mark
	 * 10 marks 
	 * @throws Exception *******************************************************************
	 */
	/**
	 * Calculate the semester mark using the weights and marks contained in the tree
	 * @param tree
	 * @param root
	 * @return the semester mark
	 * @throws Exception
	 */
	
	
	private static Double calcSM(Tree<Mark> tree, Position<Mark> root) throws Exception {
	    Mark current = root.element();
	    
	    // If this is a leaf node (external node with mark value)
	    if (current.name == null) {
	        return current.value.doubleValue(); // Return the mark value directly
	    }
	    
	    double weightedSum = 0.0;
	    Iterator<Position<Mark>> children = tree.children(root);
	    
	    while (children.hasNext()) {
	        Position<Mark> child = children.next();
	        Mark childMark = child.element();
	        double childValue = calcSM(tree, child);
	        
	        // If the child is an internal node (has a name and weight)
	        if (childMark.name != null) {
	            // Multiply the child's value by its weight percentage
	            weightedSum += childValue * (childMark.value / 100.0);
	        } else {
	            // For leaf nodes, just add their value
	            weightedSum += childValue;
	        }
	    }
	    
	    // For the root node (CSC3A), we don't apply its weight (100)
	    if (current.name.equals("CSC3A")) {
	        return weightedSum;
	    }
	    
	    // For other internal nodes, apply their weight to their children's average
	    return weightedSum * (current.value / 100.0);
	}

	


}
