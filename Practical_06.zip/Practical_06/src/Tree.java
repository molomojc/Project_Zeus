import java.util.Iterator;

public class Tree<T>{
    private TreeNode<T> root = null;
    private Integer size = 0;
    
    public Tree() {
        size = 0;
        root = new TreeNode<T>(null, null);
    }
    
    public Tree(T element) {
        super();
        root = new TreeNode<T>(null, element);
        size = 1;
    }
    
    public Position<T> root() {
        return root;
    }
    
    public Iterator<Position<T>> children(Position<T> node) throws Exception {
        TreeNode<T> treeNode = checkPosition(node);
        return treeNode.getChildren();
    }

    public Position<T> parent(Position<T> node) throws Exception {
        TreeNode<T> treeNode = checkPosition(node);
        return treeNode.getParent();
    }
    
    // 5 marks
    public Position<T> addElementAsChild(Position<T> node, T element) throws Exception {
        TreeNode<T> treeNode = checkPosition(node);
        TreeNode<T> newNode = treeNode.addChild(element);
        size++;
        return newNode;
    }
    
    public void setElement(Position<T> pos, T element) throws Exception {
        TreeNode<T> node = checkPosition(pos);
        node.setElement(element);
    }
    
    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
    
    private TreeNode<T> checkPosition(Position<T> p) throws Exception {
        if (!(p instanceof TreeNode<?>)) {
            throw new Exception("Invalid Position");
        }
        return (TreeNode<T>)p;
    }

    // 10 marks
    public String preOrderElementTraversal(Tree<T> tree, Position<T> root) throws Exception {
        StringBuilder sb = new StringBuilder();
        preOrderTraversalHelper(tree, root, 0, sb);
        return sb.toString();
    }
    
    private void preOrderTraversalHelper(Tree<T> tree, Position<T> node, int depth, StringBuilder sb) throws Exception {
        // Add indentation based on depth
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
        sb.append(node.element().toString()).append("\n");
        
        // Recursively process children
        Iterator<Position<T>> children = tree.children(node);
        while (children.hasNext()) {
            preOrderTraversalHelper(tree, children.next(), depth + 1, sb);
        }
    }
    
    // 5 marks
    public Integer depth(Tree<T> tree, Position<T> v) {
        if (v == tree.root()) {
            return 0;
        }
        try {
            return 1 + depth(tree, tree.parent(v));
        } catch (Exception e) {
            return 0;
        }
    }
    
    /**
     * Determine if a given node in an internal node
     * @param tree
     * @param p
     * @return boolean - true if node is internal
     * @throws Exception
     * 5 marks *******************************************************************
     */
    public Boolean isInternal(Tree<T> tree, Position<T> p) throws Exception {
        TreeNode<T> node = checkPosition(p);
        return node.getChildren().hasNext();
    }
}