package csc2b.client;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;

/*
 * @Author JM Molomo
 * @Version P04
 */
public class ClientHelper{
      private PrintWriter pw;
      private BufferedReader br;
      private DataOutputStream dos;
      private DataInputStream dis;
      private Socket ss;
      private Pane pane;
      public ClientHelper()
      {
    	 pane = new Pane();
    	 MainGUI();
      }
	private void MainGUI() {
		// TODO Auto-generated method stub
		pane.setPrefSize(600, 500);
		//login Details
		Pane LoginDetails = new Pane();
		//host

	
		TextField Username = new TextField();
		Username.setPromptText("Username");
		Username.setText("Riri");
		Username.setLayoutX(240);
		Username.setLayoutY(150);
		Username.setPrefSize(160, 35);
		//Password
		TextField Password = new TextField();
		Password.setPromptText("Password");
		Password.setText("123");
		Password.setLayoutX(240);
		Password.setLayoutY(200);
		Password.setPrefSize(160, 35);
		//Login
		Button Login = new Button("LOGIN");
		Login.setLayoutX(240);
		Login.setLayoutY(250);
		Login.setPrefSize(160, 35);
		Login.setOnAction(e -> {
			if((Login(Username.getText(),Password.getText())) == true )
			{
				Interract();
			}
		});
		LoginDetails.getChildren().addAll(Username,Password,Login);
		pane.getChildren().add(LoginDetails);
	}
	//The interacting with server
	
	private void Interract()
	{
		pane.getChildren().clear();
		pane.setPrefSize(600, 500);
		Pane Home = new Pane();
		//testing if still connected
	    
	    TextArea tf = new TextArea();
	    //Check Avaialable files
	 
	    Button Avail = new Button("AVAILABLE FALES");
	    Avail.setLayoutX(0);
	    Avail.setLayoutY(0);
	    Avail.setPrefSize(100, 35);
	    
	    //Update
	     tf.setLayoutX(110);
	     tf.setLayoutY(0);
	     tf.setPrefSize(150, 150);
	     Avail.setOnAction(e -> {
	    	 List(tf);
	    	
	     });
	    
	   
	    TextField TA = new TextField(); 
	  
	    Button Download = new Button("DOWNLOAD");
	    Download.setLayoutX(0);
	    Download.setLayoutY(160);
	    Download.setPrefSize(100, 35);
	    
	    TA.setLayoutX(110);
	    TA.setLayoutY(160);
	    TA.setPrefSize(80,35);
	    Download.setOnAction(e -> {
	    	ImageDownload(TA);
	    });

	   Button logof = new Button("LOGOFF");
	   logof.setLayoutX(0);
	   logof.setLayoutY(350);
	   logof.setOnAction(e -> {
		   Close();
		   if(ss.isClosed()) {
			   print("GOODBYE");
		   }else
		   {
			   print("STILL HERE BOII");
		   }
	   });
	    
		Home.getChildren().addAll(Avail,tf,Download,TA,logof);
		pane.getChildren().add(Home);
	}
	
	//DOWNLOAD IMage
	private void ImageDownload(TextField TA)
	{
		pw.println("DOWN " + TA.getText());
		
		try
		{
			String responce1;
			if((responce1 = br.readLine()) != null)
			{
				print("The file: " + responce1 + "is beginning tobe downloaded");
				File file  = new File("data/client/" + responce1);
				String responce2;
				if((responce2 = br.readLine()) != null)
				{
				   long size = Long.parseLong(responce2);
				   print("The size is: " + size);
					try(BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file)))
					{
						byte[] buffer = new byte[1024];
						int bytee;
						int Total = 0;
						while( Total < size)
						{
							bytee = dis.read(buffer, 0, buffer.length);
							bos.write(buffer, 0, bytee);
							Total += bytee;
						}
						bos.flush();
						print("The File: " + file.getAbsolutePath());
					}catch(IOException e)
					{
						e.printStackTrace();
					}
				}
			}
			
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

	//RETRIEVE THE LIST
	private void List(TextArea tf)
	{
		pw.println("LIST");
		try
		{
			String line;
			while((line = br.readLine()) != null)
			{
				if(line.equals("END"))
				{
					break;
				}
				tf.appendText(line + "\n");
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	private void Close()
	{
		try
		{
			ss.close();
			pw.close();
			br.close();
			dis.close();
			dos.close();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	//LOGIN TO CLIENT
	private boolean Login(String Username, String Password)
	{
		boolean result = false;
		Connect("localhost",2018);
		pw.println("AUTH "+ Username +" "+ Password);
		pw.flush();
		
		try
		{
			String responce;
			if((responce = br.readLine()) != null)
			{
				if(responce.startsWith("2")) {
					result = true;
					print(responce);
				}
				else
				{
					result = false;
					print(responce);
				}
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		return result;
		
	}
	
	private void print(String line)
	{
		System.out.println(line);
	}
	
	private void Connect(String Host,int Port)
	{
		
		try
		{
			
			ss = new Socket(Host,Port);
			if(ss.isConnected())
			{
				print("The first lauch is connected");
			}
			//bind streams
			pw = new PrintWriter(ss.getOutputStream(),true );
			br = new BufferedReader(new InputStreamReader( ss.getInputStream()));
			dos = new DataOutputStream(ss.getOutputStream());
			dis = new DataInputStream(ss.getInputStream());
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}
	/**
	 * @return the pane
	 */
	public Pane getPane() {
		return pane;
	}
}
