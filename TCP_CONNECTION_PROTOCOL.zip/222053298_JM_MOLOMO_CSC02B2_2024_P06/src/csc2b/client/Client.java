package csc2b.client;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Client extends Application{
   public static void main(String[] args)
   {
	   launch(args);
   }
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		ClientHelper _Client = new ClientHelper();
		Scene _Scene = new Scene(_Client.getPane());
		arg0.setScene(_Scene);
		arg0.setTitle("CLIENT");
		arg0.show();
	}
 
	
}
