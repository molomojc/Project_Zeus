package csc2b.server;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ServerHelper implements Runnable{
   private Socket ss;
   private PrintWriter pw;
   private BufferedReader br;
   private DataInputStream dis;
   private DataOutputStream dos;
	
	public ServerHelper(Socket _SS)
	{
		this.ss = _SS;
		try
		{
			pw = new PrintWriter(_SS.getOutputStream(),true);
			br = new BufferedReader(new InputStreamReader(_SS.getInputStream()));
			dis = new DataInputStream(_SS.getInputStream());
			dos = new DataOutputStream(_SS.getOutputStream());
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
       try
       {
    	   String request;
    	   while((request = br.readLine()) != null)
    	   {
    		   //split the request
    		   String Command[] = request.split(" ");
    		   if(Command[0].equals("AUTH"))
    		   {
    			   Authenticate(Command[1],Command[2]);
    		   }
    		   else if(Command[0].equals("LIST"))
    		   {
    			   sendList();
    		   }
    		   else if(Command[0].equals("DOWN"))
    		   {
    			   SendFile(Command[1]);
    		   }
    		 
    		
    	   } 
    	   //br.close();
       }catch(IOException e)
       {
    	   e.printStackTrace();
       }
		
	}
	//send the File
	private void SendFile(String ID)
	{
		File file = new File("data/server/PDFList.txt");
		try(BufferedReader br = new BufferedReader(new FileReader(file)))
		{
			String line;
			while((line = br.readLine()) != null)
			{
				if(line.contains(ID))
				{
					String name[] = line.split(" ");
					String Fname = name[1];
					
			      pw.println(Fname);
			      File fiile = new File("data/server/" + Fname);  //Update [path
			      pw.println(fiile.length());
			      
			      FileInputStream fis = new FileInputStream(fiile);
			      byte[] buffer = new byte[1024];
			      int buy;
			      while((buy = fis.read(buffer)) != -1)
			      {
			    	  dos.write(buffer, 0, buy);
			      }
			      dos.flush();
			      fis.close();
				}
			}
			
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}


	//send the List
	private void sendList()
	{
		File file = new File("data/server/PDFList.txt");
		try(BufferedReader br = new BufferedReader(new FileReader(file)))
		{
			String name;
			while((name = br.readLine()) != null)
			{
				pw.println(name);
			}
			pw.println("END");
			
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	private boolean checkUser(String username, String Password)
	{
		boolean result = false;
		File file = new File("data/server/users.txt");
		try(BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line;
			while((line = br.readLine()) != null)
			{
				String users[] = line.split(" ");
				if(users[0].equals(username) && users[1].equals(Password))
				{
					result = true;
				}
				else
				{
					result = false;
				}
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	private void Authenticate(String User, String pass) {
		if((checkUser(User,pass)) == true)
		{
			pw.println("200 OK LOGIN SUCCESSFUL");
		}
		else
		{
			pw.println("500 FAILED TO LOGIN");
		}
		
	}

}
