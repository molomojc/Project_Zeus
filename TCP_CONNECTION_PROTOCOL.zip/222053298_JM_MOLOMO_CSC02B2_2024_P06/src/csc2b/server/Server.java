package csc2b.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * @Author JM Molomo
 * @Version P04
 */
public class Server {
   private ServerSocket sS;
   private Socket ss;
   private int Port = 2018;
   public Server()
   {
	   try
	   {
		  sS = new ServerSocket(2018);
		  Run();
	   }catch(IOException e)
	   {
		   e.printStackTrace();
	   }
   }
private void Run() {
	// TODO Auto-generated method stub
	System.out.println("THE SERVER IS RUNNING...." );
	try
	{
		while(true)
		{
			ss = sS.accept(); //Accept the connection
			ServerHelper sH = new ServerHelper(ss);
			Thread newThread = new Thread(sH);
			newThread.start();
		}
		
	}catch(IOException e)
	{
		e.printStackTrace();
	}
}


public static void main(String[] args)
{
	Server ss = new Server();
}
}
